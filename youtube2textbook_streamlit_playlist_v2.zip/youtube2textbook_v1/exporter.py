"""Book export utilities. Text-based Markdown subset; no arbitrary HTML execution."""
from io import BytesIO
import re
from docx import Document
from docx.shared import Pt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Preformatted, PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import ParagraphStyle
from xml.sax.saxutils import escape
from engine import assembled

def markdown_bytes(pid): return assembled(pid).encode('utf-8')

def docx_bytes(pid):
    doc=Document(); doc.styles['Normal'].font.size=Pt(10)
    for line in assembled(pid).splitlines():
        if line.startswith('### '): doc.add_heading(line[4:],3)
        elif line.startswith('## '): doc.add_heading(line[3:],2)
        elif line.startswith('# '): doc.add_heading(line[2:],1)
        elif line.startswith('- '): doc.add_paragraph(line[2:],style='List Bullet')
        elif re.match(r'^\d+\. ',line): doc.add_paragraph(re.sub(r'^\d+\. ','',line),style='List Number')
        elif line.strip() and line.strip()!='---': doc.add_paragraph(line)
    out=BytesIO(); doc.save(out); return out.getvalue()

def pdf_bytes(pid):
    styles=getSampleStyleSheet(); styles.add(ParagraphStyle(name='BookCode',parent=styles['Code'],fontSize=8,leading=11))
    out=BytesIO(); pdf=SimpleDocTemplate(out,pagesize=(595,842),rightMargin=50,leftMargin=50,topMargin=48,bottomMargin=48)
    story=[]; in_code=False
    for line in assembled(pid).splitlines():
        if line.startswith('```'): in_code=not in_code; continue
        if not line.strip(): story.append(Spacer(1,6)); continue
        if line.strip()=='---': story.append(Spacer(1,15)); continue
        if in_code:
            story.append(Preformatted(line[:100],styles['BookCode'])); continue
        n=len(line)-len(line.lstrip('#'))
        if n in (1,2,3) and line[n:n+1]==' ':
            style=styles[{1:'Title',2:'Heading1',3:'Heading2'}[n]]
            story.append(Paragraph(escape(line[n+1:]),style))
        else:
            clean=re.sub(r'\*\*(.*?)\*\*',r'\1',line)
            story.append(Paragraph(escape(clean),styles['BodyText']))
    pdf.build(story); return out.getvalue()
