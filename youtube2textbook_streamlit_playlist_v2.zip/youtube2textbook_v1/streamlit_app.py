import os
import streamlit as st
from engine import (ROOT, Model, assembled, captions_from_youtube, create_project, create_playlist_project, playlist_info, captions_from_entries, generate_chapter, outline_project, project_dir, projects, quality_report, read_json)
from exporter import markdown_bytes, docx_bytes, pdf_bytes

st.set_page_config(page_title='YouTube2Textbook AI',page_icon='📚',layout='wide')
st.title('📚 YouTube2Textbook AI')
st.caption('Build original, in-depth educational books from permitted video transcripts. Generated text requires review.')

with st.sidebar:
    st.header('AI configuration')
    provider=st.selectbox('Provider',['Groq-compatible API','Ollama'])
    default_model='llama-3.3-70b-versatile' if provider!='Ollama' else 'qwen2.5:3b'
    model_name=st.text_input('Model name',value=default_model)
    key=st.text_input('API key',value=os.environ.get('GROQ_API_KEY',''),type='password',disabled=provider=='Ollama')
    endpoint=st.text_input('Custom API base URL (optional)',value='')
    st.info('API key is used for this session only. For Streamlit Cloud, set GROQ_API_KEY in app Secrets.')

def model_client(): return Model('Ollama' if provider=='Ollama' else 'API',model_name,key,endpoint)

page=st.radio('Workspace',['Create project','My books','Chapters & interview Q&A','Export & review'],horizontal=True)
if page=='Create project':
    name=st.text_input('Textbook title',value='My AI Textbook')
    mode=st.selectbox('Depth',['Essentials','Complete','Expert','Job Ready','Interview Level','Crash Course'],index=1)
    qcount=st.select_slider('Interview questions per chapter',options=[10,20,30,50,100],value=20)
    method=st.radio('Source',['YouTube URL','Upload transcript'],horizontal=True)
    source=''; transcript=''
    playlist_result=None
    if method=='YouTube URL':
        url=st.text_input('YouTube video / playlist URL (HTTPS)',key='youtube_url')
        limit=st.slider('Maximum videos to discover',1,100,20)
        st.caption('Playlists are imported in order, one video at a time. Public English captions required; blocked videos are reported and skipped.')
        if st.button('Discover playlist / video',disabled=not url):
            try:
                with st.spinner('Discovering videos...'):
                    info=playlist_info(url,max_videos=limit)
                st.session_state['playlist_discovery']=(url,info)
                st.session_state.pop('playlist_extracted',None)
            except Exception as exc: st.error(str(exc))
        discovery=st.session_state.get('playlist_discovery')
        if discovery and discovery[0]==url:
            info=discovery[1]
            st.write(f"**{info['title']}** — {len(info['videos'])} video(s) discovered")
            options=list(range(len(info['videos'])))
            selected=st.multiselect('Choose videos in playlist order',options,default=options,
                format_func=lambda i:f"{i+1}. {info['videos'][i]['title']}")
            if st.button('Extract selected captions',disabled=not selected):
                try:
                    progress=st.progress(0,text='Starting caption extraction')
                    def update(i,n,title):
                        progress.progress(min(1,i/max(n,1)),text=f'{i}/{n}: {title[:65]}')
                    with st.spinner('Processing videos sequentially...'):
                        extracted=captions_from_entries([info['videos'][i] for i in sorted(selected)],update)
                    st.session_state['playlist_extracted']=(url,extracted)
                except Exception as exc: st.error(str(exc))
            extracted_state=st.session_state.get('playlist_extracted')
            if extracted_state and extracted_state[0]==url:
                playlist_result=extracted_state[1]
                st.success(f"Extracted {len(playlist_result['videos'])} videos; skipped {len(playlist_result['failures'])}")
                for failed in playlist_result['failures']:
                    st.warning(f"{failed['title']}: {failed['reason']}")
                if playlist_result['videos']:
                    source=url
                    transcript='\n\n'.join(v['transcript'] for v in playlist_result['videos'])
                    st.caption(f'{len(transcript.split()):,} caption words from selected videos')
    else:
        upload=st.file_uploader('Upload your permitted TXT or VTT transcript',type=['txt','vtt'])
        if upload:
            raw=upload.getvalue().decode('utf-8-sig')
            from engine import strip_vtt
            transcript=strip_vtt(raw) if upload.name.endswith('.vtt') else raw
            source='Uploaded transcript: '+upload.name
            st.caption(f'{len(transcript.split()):,} words')
    if st.button('Create textbook project',type='primary',disabled=not transcript):
        try:
            pid=create_playlist_project(name,source,playlist_result,mode,qcount) if playlist_result is not None else create_project(name,source,transcript,mode,qcount)
            st.session_state['project_id']=pid
            st.success('Project created. Open My books to generate a syllabus.')
        except Exception as exc: st.error(str(exc))

books=projects()
if page!='Create project':
    if not books:
        st.info('No projects yet. Create a project first.'); st.stop()
    names={p['id']:p['name']+' — '+p['created'] for p in books}
    pid=st.selectbox('Select textbook',options=list(names),format_func=lambda p:names[p],index=list(names).index(st.session_state['project_id']) if st.session_state.get('project_id') in names else 0)
    path=project_dir(pid)
    outline=read_json(path/'outline.json',[])
    if page=='My books':
        st.json(read_json(path/'meta.json'))
        manifest=read_json(path/'playlist_manifest.json')
        if manifest:
            st.subheader('Playlist sources')
            st.dataframe(manifest['videos'],hide_index=True)
            if manifest['failures']: st.warning(f"{len(manifest['failures'])} videos could not be imported.")
        if st.button('Generate AI syllabus',type='primary'):
            try:
                with st.spinner('Reading source and planning chapter structure...'):
                    outline=outline_project(pid,model_client())
                st.success(f'Created {len(outline)} chapters')
            except Exception as exc: st.error(f'Syllabus failed: {exc}')
        if outline:
            for i,ch in enumerate(outline,1):
                with st.expander(f'Chapter {i}: {ch["title"]}'):
                    st.write('Topics: '+', '.join(ch['topics']))
                    st.write('Objectives: '+', '.join(ch['objectives']))
    elif page=='Chapters & interview Q&A':
        if not outline: st.warning('Generate a syllabus in My books first.')
        else:
            index=st.selectbox('Chapter',range(len(outline)),format_func=lambda i:f'{i+1}. {outline[i]["title"]}')
            chapter_file=path/'chapters'/f'{index+1:03}.md'
            if st.button('Generate chapter with interview Q&A',type='primary'):
                try:
                    with st.spinner('Writing chapter; this may take several minutes...'):
                        generate_chapter(pid,index,model_client())
                    st.success('Chapter generated and checkpointed')
                except Exception as exc: st.error(f'Generation failed: {exc}')
            if chapter_file.exists():
                content=chapter_file.read_text(encoding='utf-8')
                edited=st.text_area('Edit and review chapter Markdown',value=content,height=430,key=f'edit_{pid}_{index}')
                if st.button('Save chapter edits'):
                    chapter_file.write_text(edited,encoding='utf-8'); st.success('Saved')
                with st.expander('Rendered chapter preview'): st.markdown(edited)
            else: st.info('Chapter not generated yet. Generate chapters one at a time to stay within memory and API limits.')
    else:
        report=quality_report(pid); st.subheader('Quality and completion report'); st.json(report)
        st.warning('Automated source verification, code execution, plagiarism checking and human review are NOT performed. Do not publish without review.')
        if report['chapters_written']:
            st.download_button('Download Markdown',markdown_bytes(pid),file_name='textbook.md',mime='text/markdown')
            try:
                st.download_button('Download DOCX',docx_bytes(pid),file_name='textbook.docx',mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                st.download_button('Download PDF',pdf_bytes(pid),file_name='textbook.pdf',mime='application/pdf')
            except Exception as exc: st.error('Export failed: '+str(exc))
        else: st.info('Generate at least one chapter before exporting.')
