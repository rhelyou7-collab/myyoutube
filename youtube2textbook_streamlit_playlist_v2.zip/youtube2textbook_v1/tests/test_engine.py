import os, tempfile, unittest
from pathlib import Path
import engine
from exporter import markdown_bytes, docx_bytes, pdf_bytes
class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); engine.ROOT=Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def test_url_validation(self):
        self.assertEqual(engine.validate_url('https://youtu.be/abc'),'https://youtu.be/abc')
        for url in ['http://youtube.com/watch?v=a','https://evil.com/a','file:///etc/passwd']:
            with self.assertRaises(ValueError): engine.validate_url(url)
    def test_vtt(self):
        self.assertEqual(engine.strip_vtt('WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nHello\nHello\n'), 'Hello')
    def test_project_exports(self):
        pid=engine.create_project('Test','Uploaded','hello world '*30)
        engine.save_json(engine.project_dir(pid)/'outline.json',[{'title':'Foundations','topics':['Basics'],'objectives':['Learn']}])
        f=engine.project_dir(pid)/'chapters'/'001.md'; f.parent.mkdir(); f.write_text('# Chapter 1\n\nHello world',encoding='utf-8')
        self.assertIn(b'Chapter 1',markdown_bytes(pid))
        self.assertGreater(len(docx_bytes(pid)),1000)
        self.assertTrue(pdf_bytes(pid).startswith(b'%PDF'))
        self.assertEqual(engine.quality_report(pid)['chapters_written'],1)
if __name__=='__main__': unittest.main()

class PlaylistTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); engine.ROOT=Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def test_playlist_project_manifest(self):
        data={'videos':[{'id':'abcdefghijk','title':'First lesson','url':'https://www.youtube.com/watch?v=abcdefghijk','transcript':'basics '*50}], 'failures':[{'id':'x','title':'Missing','reason':'No captions'}]}
        pid=engine.create_playlist_project('Book','https://youtube.com/playlist?list=foo',data)
        manifest=engine.read_json(engine.project_dir(pid)/'playlist_manifest.json')
        self.assertEqual(manifest['videos'][0]['word_count'],50)
        self.assertEqual(len(manifest['failures']),1)
    def test_playlist_info_mock(self):
        from unittest.mock import patch
        import json
        fake={'title':'Sample course','_type':'playlist','entries':[{'id':'abcdefghijk','title':'Lesson 1'},{'id':'12345678901','title':'Lesson 2'}]}
        with patch('engine.subprocess.run') as run:
            run.return_value.returncode=0
            run.return_value.stdout=json.dumps(fake)
            info=engine.playlist_info('https://www.youtube.com/playlist?list=abc')
        self.assertEqual(len(info['videos']),2)
    def test_partial_playlist_failures(self):
        from unittest.mock import patch
        entries=[{'id':'abcdefghijk','title':'A','url':'https://youtu.be/abcdefghijk'}, {'id':'12345678901','title':'B','url':'https://youtu.be/12345678901'}]
        with patch('engine.captions_from_youtube',side_effect=[[('track','hello '*40)],RuntimeError('blocked')]):
            result=engine.captions_from_entries(entries)
        self.assertEqual((len(result['videos']),len(result['failures'])),(1,1))
