# YouTube2Textbook AI — Streamlit MVP

Working implementation of a sequential textbook authoring workflow. **Not a fully validated production publishing system.**

## Features
- Extract accessible English YouTube video/playlist captions with yt-dlp (up to 20 items per import), or upload permitted TXT/VTT transcripts.
- Create an AI-planned chapter syllabus with objectives and topic lists.
- Generate individual long-form Markdown chapters with exercises and interview Q&A; save each chapter to disk immediately.
- Review and edit chapters in Streamlit, export Markdown/DOCX/PDF.
- Track generation provenance (model, source checksum, timestamp), identify missing chapters, and surface review requirements.
- Use Groq-compatible Chat Completions APIs or local Ollama; no hardcoded secrets.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export GROQ_API_KEY='your_key_here'  # or use Ollama locally
streamlit run streamlit_app.py
python -m unittest discover -s tests -v
```

## Streamlit Community Cloud
1. Push this folder to a GitHub repository. Set main file path to `streamlit_app.py`.
2. In the Streamlit Cloud app Secrets, add `GROQ_API_KEY = "..."`. Never commit credentials.
3. Deploy and test transcript upload first; YouTube can block cloud server requests.
4. Cloud local disk is **ephemeral**. The included file-based project storage is for demo/local use, NOT durable cloud persistence. Export your files immediately. Add an external DB/object store before using with real projects.
5. Large playlists may exceed cloud execution/time limits. Run smaller batches; Ollama typically requires a separately hosted reachable instance.

## Operational and safety limits
- Transcript content is treated as untrusted; no direct tool execution from model output.
- Generated chapters are **drafts**, not independently fact-checked or plagiarism-checked. Review every chapter, citations and code before publishing.
- No automatic independent verification or code sandbox, despite structured warnings and audit logs. These require additional integrations.
- Interview Q&A counts are requested from the model, not programmatically guaranteed.
- PDF/DOCX export handles a Markdown subset; complex tables, diagrams, math and code blocks may need manual formatting.
- API model IDs and availability vary; enter a currently supported model in the sidebar.
- Only process transcripts you have rights or permission to use, and respect platform access controls.
- No authentication or tenant isolation. Deploy privately or add authentication before handling confidential materials.

## Playlist workflow (v2)
1. Paste a YouTube video or playlist URL on **Create project**.
2. Click **Discover playlist / video**, choose which entries to import, and click **Extract selected captions**.
3. Review skipped/unavailable videos; create the textbook project from successfully extracted captions.
4. Open **My books** to view the ordered video source manifest and generate the syllabus.
5. Generate chapters individually and export the book.

Playlist discovery is limited to 100 videos per import, with a default of 20. Extraction is sequential and may be slow; the browser session must remain active. Caption access is not guaranteed on Streamlit Cloud. No audio downloads or speech-to-text fallback are included. Persistent cloud storage, asynchronous job workers and source-grounded chapter attribution are future work.
